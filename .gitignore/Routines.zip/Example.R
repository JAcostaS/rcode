## Librerias y Fuentes

#library("jpeg")
#library("akima")
#library("fields")
#library("graphics")

source("Noises.R")
source("Input.R")
source("Codismap.R")
source("hCodismap.R")
dyn.load("hCodismap.so")
dyn.load("hCodismap.dll")


#######################################################
##### Example Regular Grid ############################
sim1=simmatern2(256, 0.5,0.5,1,1,0.5,0.5,0.1)

X1 <- sim1[[1]]
Y1 <- sim1[[2]]

SP_Y1 <- saltnpepper(Y1, epsilon = 0.25)
NAcont_Y1 <- NAcont(Y1, epsilon=0.001, k=5)
NAblock_Y1<- NAblock(Y1, k=50, m=1)
Input_Y1 <- Input(y=NAblock_Y1, k=50)

par(mfrow=c(2,3), pty="s",mar=c(2,2,1,1))
image(X1,main="Image X1", col=gray((0:32)/32))
image(Y1,main="Image Y1", col=gray((0:32)/32))
image(SP_Y1,main="Salt and Pepper", col=gray((0:32)/32))
image(NAcont_Y1,main="Missing Block", col=gray((0:32)/32))
image(NAblock_Y1,main="Gaps", col=gray((0:32)/32))
image(Input_Y1,main="Input", col=gray((0:32)/32))

hCodismap(x=X1, y=Y1, r=3, l=2, lwd=4, plotname="ejemplo1.jpg")
hCodismap(x=X1, y=SP_Y1, r=3, l=2, lwd=4, semicirc=FALSE, plotname="ejemplo2.jpg", zlim=c(-0.5,0.5))
hCodismap(x=X1, y=NAcont_Y1, r=3, l=2, lwd=4, semicirc=FALSE, plotname="ejemplo3.jpg", zlim=c(-0.5,0.5))
hCodismap(x=X1, y=NAblock_Y1, r=2, l=2, lwd=4, plotname="ejemplo4.jpg", col=topo.colors(256))
hCodismap(x=X1, y=Input_Y1, r=3, l=2, lwd=4, plotname="ejemplo5.jpg", col=gray((0:256)/256), zlim=c(-0.5,0.5))


#######################################################
##### Example Regular Grid ############################

codisp.map(x=geoR.ls[[5]]$data, y=Al.pred.ls[[5]]$data, coords=geoR.ls[[5]]$coord,lwd=4)
codisp.map(x=geoR.ls[[5]]$data, y=Al.pred.ls[[5]]$data, coords=geoR.ls[[5]]$coord,lwd=4, simicirc=FALSE)

